# SafeSight API

## GET /health
Returns backend/model status.

## GET /api/demo
Returns sample dashboard data for a frontend demo without model weights.

## POST /api/analyze-frame
Upload one image:

```bash
curl -X POST "http://127.0.0.1:8000/api/analyze-frame" \
  -F "file=@frame.jpg"
```

The response contains detection labels, confidence scores, bounding boxes, and safety alerts.
