import { useEffect, useState } from "react";

const API = "http://127.0.0.1:8000";

export default function App() {
  const [data, setData] = useState(null);
  const [health, setHealth] = useState(null);

  useEffect(() => {
    Promise.all([
      fetch(`${API}/api/demo`).then((r) => r.json()),
      fetch(`${API}/health`).then((r) => r.json()),
    ]).then(([demo, serviceHealth]) => {
      setData(demo);
      setHealth(serviceHealth);
    });
  }, []);

  return (
    <main className="page">
      <header className="header">
        <div>
          <p className="eyebrow">AI CONSTRUCTION SAFETY</p>
          <h1>SafeSight</h1>
          <p className="subtitle">
            Real-time PPE monitoring and safety alerts.
          </p>
        </div>

        <span className={`status ${health?.model_ready ? "ready" : "demo"}`}>
          {health?.model_ready ? "MODEL ONLINE" : "DEMO MODE"}
        </span>
      </header>

      <section className="stats">
        <Stat title="Active Cameras" value={data?.active_cameras ?? "-"} />
        <Stat title="Workers Detected" value={data?.workers_detected ?? "-"} />
        <Stat title="Open Alerts" value={data?.open_alerts ?? "-"} />
      </section>

      <section className="panel">
        <div className="panel-heading">
          <div>
            <h2>Recent Safety Alerts</h2>
            <p>Latest PPE-related violations.</p>
          </div>
        </div>

        <div className="alerts">
          {(data?.recent_alerts ?? []).map((alert, index) => (
            <article className="alert" key={`${alert.violation}-${index}`}>
              <div className="alert-icon">!</div>
              <div className="alert-content">
                <strong>{alert.violation}</strong>
                <span>
                  Confidence: {(alert.confidence * 100).toFixed(0)}%
                </span>
              </div>
              <span className="severity">{alert.severity}</span>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function Stat({ title, value }) {
  return (
    <article className="stat">
      <span>{title}</span>
      <strong>{value}</strong>
    </article>
  );
}
