from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_path: str = "../models/best.pt"
    confidence_threshold: float = 0.40
    cors_origin: str = "http://localhost:5173"

    model_config = SettingsConfigDict(env_prefix="SAFESIGHT_", extra="ignore")


settings = Settings()
