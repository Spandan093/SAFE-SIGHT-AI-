from __future__ import annotations

from typing import Annotated

import cv2
import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .alerts import build_alerts, serialize_alerts
from .detector import SafetyDetector
from .settings import settings


app = FastAPI(
    title="SafeSight API",
    description="AI construction safety monitoring API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.cors_origin],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

detector = SafetyDetector()


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_ready": detector.ready,
        "model_error": detector.error,
    }


@app.post("/api/analyze-frame")
async def analyze_frame(file: Annotated[UploadFile, File(...)]):
    content = await file.read()
    image = cv2.imdecode(np.frombuffer(content, dtype=np.uint8), cv2.IMREAD_COLOR)

    if image is None:
        raise HTTPException(status_code=400, detail="Invalid image file.")

    if not detector.ready:
        return {
            "model_ready": False,
            "message": "Model weights are not configured.",
            "detections": [],
            "alerts": [],
        }

    detections = detector.detect(image)
    alerts = build_alerts(detections)

    return {
        "model_ready": True,
        "detections": [
            {
                "label": d.label,
                "confidence": d.confidence,
                "box": d.box,
            }
            for d in detections
        ],
        "alerts": serialize_alerts(alerts),
    }


@app.get("/api/demo")
def demo():
    return {
        "active_cameras": 3,
        "workers_detected": 14,
        "open_alerts": 2,
        "recent_alerts": [
            {
                "timestamp": "demo",
                "violation": "No helmet detected",
                "confidence": 0.93,
                "severity": "high",
            },
            {
                "timestamp": "demo",
                "violation": "No safety vest detected",
                "confidence": 0.88,
                "severity": "high",
            },
        ],
    }
