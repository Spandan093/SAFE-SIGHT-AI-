from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from .settings import settings


@dataclass
class Detection:
    label: str
    confidence: float
    box: list[int]


class SafetyDetector:
    def __init__(self, model_path: str | None = None) -> None:
        self.model_path = model_path or settings.model_path
        self.model: Any = None
        self.error: str | None = None

        try:
            from ultralytics import YOLO
            path = Path(self.model_path)
            if path.exists():
                self.model = YOLO(str(path))
            else:
                self.error = f"Model file not found: {path}"
        except Exception as exc:
            self.error = str(exc)

    @property
    def ready(self) -> bool:
        return self.model is not None

    def detect(self, frame: np.ndarray) -> list[Detection]:
        if not self.ready:
            return []

        results = self.model.predict(
            source=frame,
            conf=settings.confidence_threshold,
            verbose=False,
        )

        detections: list[Detection] = []
        names = self.model.names

        for result in results:
            if result.boxes is None:
                continue

            for box in result.boxes:
                cls_id = int(box.cls.item())
                confidence = float(box.conf.item())
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                label = names[cls_id] if isinstance(names, dict) else names[cls_id]

                detections.append(
                    Detection(
                        label=str(label),
                        confidence=confidence,
                        box=[x1, y1, x2, y2],
                    )
                )

        return detections


def annotate_frame(frame: np.ndarray, detections: list[Detection]) -> np.ndarray:
    output = frame.copy()

    for detection in detections:
        x1, y1, x2, y2 = detection.box
        text = f"{detection.label} {detection.confidence:.2f}"

        cv2.rectangle(output, (x1, y1), (x2, y2), (255, 255, 255), 2)
        cv2.putText(
            output,
            text,
            (x1, max(20, y1 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2,
        )

    return output
