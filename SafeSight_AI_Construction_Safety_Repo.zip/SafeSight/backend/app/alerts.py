from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone


@dataclass
class Alert:
    timestamp: str
    violation: str
    confidence: float
    severity: str


def build_alerts(detections) -> list[Alert]:
    alerts: list[Alert] = []
    now = datetime.now(timezone.utc).isoformat()

    for detection in detections:
        label = detection.label.lower()

        if label in {"no_helmet", "no helmet"}:
            alerts.append(
                Alert(
                    timestamp=now,
                    violation="No helmet detected",
                    confidence=detection.confidence,
                    severity="high",
                )
            )
        elif label in {"no_vest", "no vest", "no_safety_vest"}:
            alerts.append(
                Alert(
                    timestamp=now,
                    violation="No safety vest detected",
                    confidence=detection.confidence,
                    severity="high",
                )
            )

    return alerts


def serialize_alerts(alerts: list[Alert]):
    return [asdict(alert) for alert in alerts]
