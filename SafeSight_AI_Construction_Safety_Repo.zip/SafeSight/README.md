# SafeSight - AI Construction Safety Monitoring

SafeSight is a portfolio-ready starter repository based on the project description in my resume:
an AI/computer-vision construction safety monitoring system that analyzes CCTV/video feeds, detects PPE-related safety violations such as missing helmets or safety vests, and produces alerts.

> IMPORTANT: The resume does not specify the exact computer-vision model, training dataset, alert provider, or production deployment architecture. This repository therefore provides an extensible implementation scaffold rather than claiming to reproduce the original private project exactly.

## Features
- FastAPI backend for video/image analysis
- Optional YOLO/Ultralytics inference integration
- PPE violation rules for helmets and safety vests
- Alert event generation with timestamps
- React dashboard for status and recent alerts
- CORS-enabled local development setup
- Environment-based configuration

## Architecture
```text
Video / CCTV
     |
     v
FastAPI backend
     |
     v
Computer Vision detector
     |
     +--> PPE rule engine
     |
     +--> Alert events
     |
     v
React dashboard
```

## Setup

### Backend
```bash
cd backend
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API: http://127.0.0.1:8000
Docs: http://127.0.0.1:8000/docs

Set the model path to your trained weights, for example:

Windows PowerShell:
```powershell
$env:SAFESIGHT_MODEL="..\models\best.pt"
```

macOS/Linux:
```bash
export SAFESIGHT_MODEL=../models/best.pt
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite.

## Expected model labels
The code is designed around labels such as:
```text
person
helmet
vest
no_helmet
no_vest
```
Change the labels in the rule logic to match your trained model.

## Interview explanation
"SafeSight is an AI-based construction safety monitoring system. It processes CCTV or video frames using computer vision to identify workers and PPE-related safety violations such as missing helmets or safety vests. The backend exposes the detection service through FastAPI, generates alert events for unsafe conditions, and the React frontend presents monitoring status and recent violations."

## Future improvements
- WebSocket live-streaming
- Camera management
- Alert history database
- Authentication and roles
- Email/SMS notifications
- Object tracking
- Confidence thresholds per class
- Docker/cloud deployment
- Evidence-frame storage
