# Model weights

Place the trained model here, for example:

models/best.pt

The repository does not include trained weights. Update the class names in
backend/app/alerts.py and backend/app/detector.py to match your actual model.
