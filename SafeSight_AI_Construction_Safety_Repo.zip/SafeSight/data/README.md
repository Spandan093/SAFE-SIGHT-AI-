# Sample data

Put local test video/image files in this folder.

Do not commit large private datasets or CCTV footage to a public repository.
